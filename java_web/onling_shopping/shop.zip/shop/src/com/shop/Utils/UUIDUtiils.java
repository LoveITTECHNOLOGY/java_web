package com.shop.Utils;

import java.util.UUID;

public class UUIDUtiils {
	public static String getUUID(){
		return UUID.randomUUID().toString();
	}
}

package cn.jju.b1833.pojo;

public class Product {

	public char[] getProductName() {
		// TODO Auto-generated method stub
		return null;
	}

}

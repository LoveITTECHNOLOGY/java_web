package cn.jju.b1833.dao;

import java.util.List;

import cn.jju.b1833.pojo.User;

public interface UserDao{
	public List<User> get();
	
	public User getById(int id);
	
	public int add(User user);
	
	public int delete(int id);
	
	public int update(User user);

}

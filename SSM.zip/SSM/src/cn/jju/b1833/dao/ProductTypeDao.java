package cn.jju.b1833.dao;

import java.util.List;

import cn.jju.b1833.pojo.ProductType;

public interface ProductTypeDao {
	public List<ProductType> get();
	public int add(ProductType productType);

}

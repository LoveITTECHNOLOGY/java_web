package cn.jju.b1833.eshop;
//������Ʒ��Ϣ���з���
public class ProductType {
	private  int id;
	private String typeName;
	//���������Ķ���
		public ProductType() {
			super();
			// TODO Auto-generated constructor stub
		}
	public ProductType(int id, String typeName) {
		super();
		this.id = id;
		this.typeName = typeName;
	}
	
	/**
	 * @return the id
	 */
	//����ʵ����
	public int getId() {
		return id;
	}
	/**
	 * @param id the id to set
	 */
	public void setId(int id) {
		this.id = id;
	}
	/**
	 * @return the typeName
	 */
	public String getTypeName() {
		return typeName;
	}
	/**
	 * @param typeName the typeName to set
	 */
	public void setTypeName(String typeName) {
		this.typeName = typeName;
	}
	

}

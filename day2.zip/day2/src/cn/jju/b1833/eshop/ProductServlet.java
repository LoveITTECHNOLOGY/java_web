package cn.jju.b1833.eshop;

import java.io.IOException;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class ProductServlet
 */
@WebServlet("/ProductServlet")
public class ProductServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public ProductServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		request.setCharacterEncoding("utf-8");
		String action=request.getParameter("action");
		if("add".equals(action)){
			//Ϊ��ת��product_add.jspҳ�������ݵĴ���
			doAdd(request,response);
		}else if("list".equals(action)){
				//Ϊ��ת��product_list.jspҳ�������ݵĴ���
			}else if("delete".equals(action)){
					//ɾ����Ӧ����Ʒ���ٽ��µ���Ʒ��Ϣ�ַ���product_list.jsp
			}
		
	}
		/*���崦��add����ķ���*/
		protected void doAdd(HttpServletRequest request, 
				HttpServletResponse response) throws ServletException, IOException
				{
			//�����Ʒ������Ϣ�б�
			List<ProductType>data=new ProductTypeDao().get();
			//�����ݱ��浽request��
			request.setAttribute("ProductTypeList", data);
			//���зַ�
			   RequestDispatcher rd=
					   request.getRequestDispatcher("product_add.jsp");
			           rd.forward(request, response);
				}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request,response);
	}

}

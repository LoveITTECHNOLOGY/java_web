package cn.jju.b1833.eshop;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class CartServlet
 */
@WebServlet("/CartServlet")
public class CartServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public CartServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		String action=request.getParameter("action");
		String id=request.getParameter("id");
		//��ñ�����session����Ĺ��ﳵ����
		Cart cart=
				(Cart)request.getSession().getAttribute("mycart");
		if(action.equals("add")){ //������Ʒ�����ﳵ��
			if(cart==null) //�жϹ��ﳵ�����Ƿ����
				cart=new Cart();
			//���ﳵ������Ʒ
			cart.add(Integer.parseInt(id));	
		}else if(action.equals("delete")){
			//�ӹ��ﳵ�Ƴ���Ӧ����Ʒ
			cart.remove(Integer.parseInt(id));
		}else if(action.equals("edit")){//�޸���Ʒ����
			int newnumber=
					Integer.parseInt(request.getParameter("newnumber"));
			cart.edit(Integer.parseInt(id),newnumber);
		}
	
		//��cartд�뵽session��
		request.getSession().setAttribute("mycart", cart);
		//��ת��mycart.jsp��
		RequestDispatcher rd=
				request.getRequestDispatcher("cart/mycart.jsp");
		rd.forward(request, response);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
	}

}

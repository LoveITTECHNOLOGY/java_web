package cn.jju.b1833.eshop;

public class CartItem {

	int id; //��Ʒid
	String productName; //��Ʒ����
	int salePrice; //���ۼ۸�
	int saleNumber;//����
	int setsaleMoney;
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getProductName() {
		return productName;
	}
	public void setProductName(String productName) {
		this.productName = productName;
	}
	public int getSalePrice() {
		return salePrice;
	}
	public void setSalePrice(int salePrice) {
		this.salePrice = salePrice;
	}
	public int getSaleNumber() {
		return saleNumber;
	}
	public void setSaleNumber(int saleNumber) {
		this.saleNumber = saleNumber;
	}
	public int getSaleMoney() {
		return saleMoney;
	}
	public void setSaleMoney(int saleMoney) {
		this.saleMoney = saleMoney;
	}
	int saleMoney;
}
